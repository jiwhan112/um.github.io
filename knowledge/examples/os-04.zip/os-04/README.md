# OS 04 · Round Robin과 논리 시간 스케줄링 · 다운로드 실습

압축을 풀면 `os-04/README.md`와 `os-04/project/`가 있습니다. 이 README가 있는 폴더에서 시작하세요. `original/`은 보존 원본, `ko/`는 줄 끝 한국어 주석을 추가한 파생본입니다. 두 폴더의 CMakeLists.txt는 원본과 같습니다.

## 빌드와 실행

CMake 3.16 이상과 C++11/20을 지원하는 컴파일러가 필요합니다. 아래는 C++20 Debug 기준입니다.

```sh
cd project
cmake -S ko -B build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_STANDARD=20
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure -V --timeout 20
```

C++11을 확인하려면 별도 build 디렉터리에 `-DCMAKE_CXX_STANDARD=11`을 사용하세요. 원본을 빌드하려면 `-S original`을 사용합니다. 정상 출력의 핵심 줄:

```text
PASS OS04 checks=25
```

CTest 1/1·종료 코드 0이 정상입니다. stdin·외부 입력 파일·네트워크·권한 상승은 필요 없습니다. 프로그램은 인자 없이 고정된 내부 사례를 검사합니다.

## 확인한 범위와 한계

2026-10-24 Cloud Linux GCC 14.2.0 / CMake 3.31.6에서 원본과 ko를 각각 C++11/20으로 빌드하고 CTest 1/1을 확인했습니다. 단원별 검사 수는 25회입니다. 같은 조건을 반복한 것이지 독립 검사 수를 4배 늘린 것이 아닙니다. 각 표준에서 원본과 ko의 전처리 결과도 일치했습니다. 이 기록은 staging 프로젝트 검사이며 ZIP 생성·추출 검증과 별도입니다.

논리 틱으로 작업량을 나누는 모델입니다. 모든 도착 시각은 0이며 I/O·커널 선점·문맥 전환 비용은 없습니다. 작업량 합계는 최대 1,000,000입니다.

Windows/MSVC·sanitizer·TSan·실제 하드웨어 성능은 이번 실행에 포함하지 않았습니다. SDK·컴파일러·표준 라이브러리는 ZIP에 들어 있지 않습니다. 별도 이미지나 과거 첨부 ZIP은 프로그램의 실행 의존성이 아닙니다.

- 교재: https://jiwhan112.github.io/um.github.io/knowledge/os-04/
- 새 실행 환경과 내부 경로를 가린 파생 로그: https://jiwhan112.github.io/um.github.io/knowledge/shared/os-04-lab/verification.json
- 원본 복원 원장: https://jiwhan112.github.io/um.github.io/knowledge/shared/os-04-lab/source-integrity.json
