# 운영체제 02 · 가상 주소·페이지 테이블과 접근 권한 — 전체 예제

VPN·offset 계산과 매핑·권한·정수 범위를 4KiB CPU 모형으로 추적

## 압축을 푼 뒤

이 README.md 옆 project/가 완전한 프로젝트입니다. 외부 에셋이나 다른 교재는 필요하지 않습니다. CMake 3.16 이상과 C++20 지원 컴파일러/표준 스레드 라이브러리가 필요합니다.

```sh
cd project
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure -V
```

Windows 다중 구성 생성기는 build에 `--config Debug`, ctest에 `-C Debug`를 추가합니다. Windows 실제 성공은 미검증입니다. C++11 호환 확인은 새 build11 폴더에 `-DCMAKE_CXX_STANDARD=11`을 지정합니다.

## 파일과 기대 결과

- main.cpp: 한국어 주석 전체 코드.
- original/main.cpp: 기존 코드 조각을 그대로 조립한 기준.
- CMakeLists.txt: 새 독립 wrapper; 한국어판과 조립 원본판 두 실행을 등록하고 각 30초 제한.
- original/CMakeLists.txt: 원문 빌드 참고. 단독 실행용이 아닐 수 있으므로 root CMake를 사용합니다.
- provenance.json: 공개 코드 해시·조립 경계·주석 역복원 정보.

각 실행의 기대 출력:

```text
PASS 30 virtual-memory page-table CPU checks
```

같은 조건을 두 표현과 두 표준으로 반복합니다. CTest2개를 독립 조건 두 배로 합산하지 않습니다.

## 실제 확인한 범위

2026-10-24 Cloud Linux GCC14.2/CMake3.31.6에서 필요한 파일만 복사한 standalone 프로젝트로 C++20/11 Debug configure/build/CTest 각각 2/2 통과했습니다. 원문 복원과 -E -P 동일성도 확인했습니다. Windows/MSVC·ThreadSanitizer·이번 ASan/UBSan·MMU/TLB·커널 시간 측정·GPU는 실행하지 않았습니다. 사용자 컴퓨터를 사용하지 않았습니다.

OS02A의 C++ 두 블록을 표시 순서와 각 LF 그대로 이어 3378바이트 파일로 조립했습니다. 원문에 전체 파일 SHA가 제시되지 않았으므로 현재 조립 SHA는 무결성 기준이지 과거 바이너리와의 동일성 증명이 아닙니다. 02A/B의 GCC20·GCC11·ClangSan 과거 로그는 비공개 작업 기록에 보존하고 현재 실행과 분리합니다.

[현재 CPU 로그 · 내부 경로 비식별화](https://github.com/jiwhan112/um.github.io/tree/master/knowledge/shared/os-02-lab/verification) · [교재](https://jiwhan112.github.io/um.github.io/knowledge/os-02/)
