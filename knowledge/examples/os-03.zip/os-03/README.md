# 운영체제 03 · 잠금 순서·교착 위험과 RAII — 전체 예제

순서 그래프의 순환 거부와 두 mutex 취득을 서로 다른 실험으로 구분

## 압축을 푼 뒤

이 README.md 옆 project/가 완전한 프로젝트입니다. 외부 에셋이나 다른 교재는 필요하지 않습니다. CMake 3.16 이상과 C++20 지원 컴파일러/표준 스레드 라이브러리가 필요합니다.

```sh
cd project
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure -V
```

Windows 다중 구성 생성기는 build에 `--config Debug`, ctest에 `-C Debug`를 추가합니다. Windows 실제 성공은 미검증입니다. C++11 호환 확인은 새 build11 폴더에 `-DCMAKE_CXX_STANDARD=11`을 지정합니다.

## 파일과 기대 결과

- main.cpp: 한국어 주석 전체 코드.
- original/main.cpp: 기존 코드 조각을 그대로 조립한 기준.
- CMakeLists.txt: 새 독립 wrapper; 한국어판과 조립 원본판 두 실행을 등록하고 각 30초 제한.
- original/CMakeLists.txt: 원문 빌드 참고. 단독 실행용이 아닐 수 있으므로 root CMake를 사용합니다.
- provenance.json: 공개 코드 해시·조립 경계·주석 역복원 정보.

각 실행의 기대 출력:

```text
PASS OS03 checks=153618 random_order_attempts=3072 concurrent_transfers=12000
```

같은 조건을 두 표현과 두 표준으로 반복합니다. CTest2개를 독립 조건 두 배로 합산하지 않습니다.

## 실제 확인한 범위

2026-10-24 Cloud Linux GCC14.2/CMake3.31.6에서 필요한 파일만 복사한 standalone 프로젝트로 C++20/11 Debug configure/build/CTest 각각 2/2 통과했습니다. 원문 복원과 -E -P 동일성도 확인했습니다. Windows/MSVC·ThreadSanitizer·이번 ASan/UBSan·MMU/TLB·커널 시간 측정·GPU는 실행하지 않았습니다. 사용자 컴퓨터를 사용하지 않았습니다.

원문의 PART1→5 다섯 페이지에는 실제 C++ 코드 블록이 6개입니다(PART5가 둘). 각 코드 본문과 LF를 표시 순서대로 이어 조립한 파일은 6700바이트, SHA-256 5bc3ead3eedf6a427b0a5f4812058ef7bb9e2d0ab58ffbf4bc0bf0a105411c63입니다. 원문에 적힌 과거 전체 파일 SHA de607332eff349facc3366ae347644463340cb68ade1d51bd08d02238b1a69da와 다릅니다. 과거 ZIP/원시 실행 로그는 회수하지 않았으며 과거 전체 파일의 복원 완료로 주장하지 않습니다. 원본 ZIP 복원이라고 부르지 않고 코드 조각 조립본으로 제공·새 검증합니다. NET03을 요구하는 재구성 공용 CMake는 original/에 보존하고 새 단독 wrapper로 실행합니다.

[현재 CPU 로그 · 내부 경로 비식별화](https://github.com/jiwhan112/um.github.io/tree/master/knowledge/shared/os-03-lab/verification) · [교재](https://jiwhan112.github.io/um.github.io/knowledge/os-03/)
