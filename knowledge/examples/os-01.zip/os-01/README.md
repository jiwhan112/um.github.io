# 운영체제 01 · 프로세스·스레드와 닫을 수 있는 작업 큐 — 전체 예제

공유 상태, 조건 재검사, 종료 순서를 실제 표준 스레드 CPU 실습으로 연결

## 압축을 푼 뒤

이 README.md 옆 project/가 완전한 프로젝트입니다. 외부 에셋이나 다른 교재는 필요하지 않습니다. CMake 3.16 이상과 C++20 지원 컴파일러/표준 스레드 라이브러리가 필요합니다.

```sh
cd project
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure -V
```

Windows 다중 구성 생성기는 build에 `--config Debug`, ctest에 `-C Debug`를 추가합니다. Windows 실제 성공은 미검증입니다. C++11 호환 확인은 새 build11 폴더에 `-DCMAKE_CXX_STANDARD=11`을 지정합니다.

## 파일과 기대 결과

- main.cpp: 한국어 주석 전체 코드.
- original/main.cpp: 기존 코드 조각을 그대로 조립한 기준.
- CMakeLists.txt: 새 독립 wrapper; 한국어판과 조립 원본판 두 실행을 등록하고 각 30초 제한.
- original/CMakeLists.txt: 원문 빌드 참고. 단독 실행용이 아닐 수 있으므로 root CMake를 사용합니다.
- provenance.json: 공개 코드 해시·조립 경계·주석 역복원 정보.

각 실행의 기대 출력:

```text
PASS 28 OS queue CPU concurrency contract checks
```

같은 조건을 두 표현과 두 표준으로 반복합니다. CTest2개를 독립 조건 두 배로 합산하지 않습니다.

## 실제 확인한 범위

2026-10-24 Cloud Linux GCC14.2/CMake3.31.6에서 필요한 파일만 복사한 standalone 프로젝트로 C++20/11 Debug configure/build/CTest 각각 2/2 통과했습니다. 원문 복원과 -E -P 동일성도 확인했습니다. Windows/MSVC·ThreadSanitizer·이번 ASan/UBSan·MMU/TLB·커널 시간 측정·GPU는 실행하지 않았습니다. 사용자 컴퓨터를 사용하지 않았습니다.

OS01A의 전체 코드 4055바이트 SHA-256이 원문에 적힌 96cf0966e8eed1d87fbfd90fb71d82953897d1de8367603a3c9b1b62bc8fba10과 일치합니다. 01B/C의 과거 공용빌드 로그와 01D 단독 CMake를 비공개 작업 기록에 보존했습니다. 새 CMake는 한국어 주석본과 조립 원본을 독립 실행하며 두 실행을 56개 독립 조건으로 집계하지 않습니다.

OS01 원문52/101행의 여러 문장 배치로 GCC misleading-indentation 경고가 발생합니다. 경고를 숨기거나 소스를 몰래 수정하지 않았습니다. 대기 테스트는 실제 wait 진입 순서를 고정하지 않고, 개수·합 검사는 ID별 단일 처리의 완전한 증명이 아닙니다.

[현재 CPU 로그 · 내부 경로 비식별화](https://github.com/jiwhan112/um.github.io/tree/master/knowledge/shared/os-01-lab/verification) · [교재](https://jiwhan112.github.io/um.github.io/knowledge/os-01/)
