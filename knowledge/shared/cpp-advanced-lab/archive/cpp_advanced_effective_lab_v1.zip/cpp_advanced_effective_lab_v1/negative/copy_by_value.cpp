struct Bad { Bad(Bad); };
